package com.swp391.team6.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;

@SpringBootTest
class CinemaManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
